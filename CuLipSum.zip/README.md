<h1 align="center">
  <a href="http://culipsum.com/"><img src="/imgs/culipsum_logo_for_dark.svg" alt="CuLipSum" width="200"></a>
</h1>
<p align="center">Custom Lorem Ipsum Generator</p>
<p align="center">Based on the exellent lorem ipsum style dummy text generator over at <a href="http://fillerama.io/" target="_blank">fillerama.io</a>.</p>

---

03/30/2023 - Initial setup\
04/09/2023 - Output generator complete\
04/11/2023 - Input mechanism & page complete\
04/14/2023 - Version 1 is done and ready to submit to Firefox.

TODO: Package for submittal.

---

While I love the generator over at [Fillerama](http://fillerama.io/) (Futurama was one of the best!), I wanted to be able to upload my own text. Therefore, I built this Firefox Extension to let me. While there's demo material, there is also a place to upload your own content.

***Custom content will not be saved if you delete or reload the extension, so save your content separately. Since there is a way to upload text files, you'll be able to reload your content fairly easily.***